import React, { Component } from 'react';
import ParentComponent from './components/ParentComponent';
import NameList from './components/NameList';
import Persons from './components/Persons';
import Form from './components/Form';
import Header from './components/Header';
import { ToastContainer, toast } from 'react-toastify';

import 'bootstrap/dist/css/bootstrap.min.css';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import 'react-toastify/dist/ReactToastify.css';
import 'react-tabs/style/react-tabs.css';
import './App.css';
import SimpleSlider from './components/SimpleSlider';
import { Tabs } from 'react-bootstrap';
import TabsComp from './components/TabsComp';
import ModalComp from './components/ModalComp';
import VideoComp from './components/VideoComp';

class App extends Component {
  notify = () =>
    toast.error('Xatolik!', {
      position: 'top-right',
      autoClose: 5000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
      theme: 'light',
    });
  render() {
    return (
      <div>
        <Header />
        {/* <ParentComponent /> */}
        {/* <NameList /> */}
        {/* <Persons /> */}
        <Form />
        <SimpleSlider />
        <button onClick={this.notify}>Notify!</button>
        <ToastContainer />
        <TabsComp />
        <ModalComp />
        <VideoComp />
      </div>
    );
  }
}

export default App;
