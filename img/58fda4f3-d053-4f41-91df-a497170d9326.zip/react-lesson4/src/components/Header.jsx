import React, { Component } from 'react';
import { Container, Nav, Navbar } from 'react-bootstrap';

class Header extends Component {
  render() {
    return (
      <Navbar collapseOnSelect expand="lg" className="bg-body-tertiary">
        <Container>
          <Navbar.Brand href="#home">LOGO</Navbar.Brand>
          <Navbar.Toggle aria-controls="responsive-navbar-nav" />
          <Navbar.Collapse id="responsive-navbar-nav">
            <Nav className="ms-auto">
              <Nav.Link href="#features">Home</Nav.Link>
              <Nav.Link href="#pricing">About</Nav.Link>
            </Nav>
            <Nav>
              <Nav.Link href="#deets">Contacts</Nav.Link>
              <Nav.Link eventKey={2} href="#memes">
                Products
              </Nav.Link>
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>
    );
  }
}

export default Header;
