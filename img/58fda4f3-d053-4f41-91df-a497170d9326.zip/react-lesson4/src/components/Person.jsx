import React, { Component } from 'react';

class Person extends Component {
  render() {
    const { person } = this.props;
    return (
      <div className="card">
        <h2>{person.name}</h2>
        <h3>{person.id}</h3>
        <p>{person.age}</p>
        <p>{person.skill}</p>
      </div>
    );
  }
}

export default Person;
