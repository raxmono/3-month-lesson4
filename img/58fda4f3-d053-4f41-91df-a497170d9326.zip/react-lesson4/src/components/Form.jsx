import React, { Component } from 'react';

class Form extends Component {
  constructor(props) {
    super(props);

    this.state = {
      regData: {
        username: '',
        password: '',
        comment: '',
        language: 'Uzbek',
      },
    };
  }

  handleRegistrationChange = (e) => {
    this.setState({
      regData: {
        ...this.state.regData,
        [e.target.name]: e.target.value,
      },
    });
  };

  render() {
    const { handleRegistrationChange } = this;
    const { username, password, comment, language } = this.state.regData;
    return (
      <div className="container">
        <h1>Registration</h1>
        <form>
          <input
            type="text"
            placeholder="Username"
            id="username"
            name="username"
            value={username}
            onChange={handleRegistrationChange}
          />
          <input
            type="password"
            placeholder="Password"
            id="password"
            name="password"
            value={password}
            onChange={handleRegistrationChange}
          />
          <textarea
            rows={5}
            cols={30}
            placeholder="Comment"
            id="comment"
            name="comment"
            value={comment}
            onChange={handleRegistrationChange}
          />
          <select
            name="language"
            id="language"
            value={language}
            onChange={handleRegistrationChange}
          >
            <option value="Uzbek">Uzbek</option>
            <option value="Russian">Russian</option>
            <option value="English">English</option>
          </select>
        </form>
      </div>
    );
  }
}

export default Form;
