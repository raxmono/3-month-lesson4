import React, { Component } from 'react';
import ReactPlayer from 'react-player';

export class VideoComp extends Component {
  render() {
    return (
      <div className="container">
        <ReactPlayer url="https://www.youtube.com/watch?v=LXb3EKWsInQ" />
      </div>
    );
  }
}

export default VideoComp;
