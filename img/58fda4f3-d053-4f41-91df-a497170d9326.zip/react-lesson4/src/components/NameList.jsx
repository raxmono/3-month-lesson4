import React, { Component } from 'react';

export class NameList extends Component {
  constructor(props) {
    super(props);

    this.state = {
      names: ['Bruce', 'Clark', 'Diana'],
    };
  }

  render() {
    const { names } = this.state;
    const nameList = names.map((name) => <h2>{name}</h2>);

    return <div>{nameList}</div>;
  }
}

export default NameList;
