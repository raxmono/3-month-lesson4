import React, { Component } from 'react';
import ChildComponent from './ChildComponent';

export class ParentComponent extends Component {
  constructor(props) {
    super(props);

    this.state = {
      child: '',
    };
  }

  greetParent = (name) => {
    this.setState({
      child: name,
    });
  };

  render() {
    const { child } = this.state;
    return (
      <div>
        <h1>Child is {child}</h1>
        <ChildComponent greetHandler={this.greetParent} />
      </div>
    );
  }
}

export default ParentComponent;
